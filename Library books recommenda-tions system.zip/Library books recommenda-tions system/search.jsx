import React, { useState } from "react";
import "./Search.css";

const books = [
  {
    title: "1984",
    author: "George Orwell",
    category: "Fiction",
    rating: 4.6,
    status: "Available",
  },
  {
    title: "A Brief History of Time",
    author: "Stephen Hawking",
    category: "Science",
    rating: 4.5,
    status: "Available",
  },
  {
    title: "Animal Farm",
    author: "George Orwell",
    category: "History",
    rating: 4.5,
    status: "Available",
  },
  {
    title: "Atomic Habits",
    author: "James Clear",
    category: "Self Help",
    rating: 4.8,
    status: "Borrowed",
  },
  {
    title: "Clean Code",
    author: "Robert C. Martin",
    category: "Programming",
    rating: 4.6,
    status: "Available",
  },
  {
    title: "Educated",
    author: "Tara Westover",
    category: "Biography",
    rating: 4.7,
    status: "Available",
  },
  {
    title: "Eloquent JavaScript",
    author: "Marijn Haverbeke",
    category: "Programming",
    rating: 4.5,
    status: "Available",
  },
  {
    title: "Harry Potter and the Chamber of Secrets",
    author: "J.K. Rowling",
    category: "Fantasy",
    rating: 4.8,
    status: "Available",
  },
  {
    title: "Harry Potter and the Philosopher's Stone",
    author: "J.K. Rowling",
    category: "Fantasy",
    rating: 4.9,
    status: "Available",
  },
  {
    title: "Pride and Prejudice",
    author: "Jane Austen",
    category: "Romance",
    rating: 4.7,
    status: "Available",
  },
  {
    title: "Python Crash Course",
    author: "Eric Matthes",
    category: "Programming",
    rating: 4.8,
    status: "Available",
  },
  {
    title: "Sapiens",
    author: "Yuval Noah Harari",
    category: "History",
    rating: 4.7,
    status: "Available",
  },
  {
    title: "Steve Jobs",
    author: "Walter Isaacson",
    category: "Biography",
    rating: 4.4,
    status: "Available",
  },
  {
    title: "The Alchemist",
    author: "Paulo Coelho",
    category: "Self Help",
    rating: 4.6,
    status: "Available",
  },
  {
    title: "The Da Vinci Code",
    author: "Dan Brown",
    category: "Mystery",
    rating: 4.3,
    status: "Borrowed",
  },
  {
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    category: "Fiction",
    rating: 4.4,
    status: "Available",
  },
  {
    title: "The Hobbit",
    author: "J.R.R. Tolkien",
    category: "Fantasy",
    rating: 4.8,
    status: "Available",
  },
  {
    title: "The Lord of the Rings",
    author: "J.R.R. Tolkien",
    category: "Fantasy",
    rating: 4.9,
    status: "Available",
  },
  {
    title: "The Pragmatic Programmer",
    author: "Andrew Hunt",
    category: "Technology",
    rating: 4.7,
    status: "Available",
  },
  {
    title: "The Selfish Gene",
    author: "Richard Dawkins",
    category: "Science",
    rating: 4.5,
    status: "Available",
  },
  {
    title: "The Silent Patient",
    author: "Alex Michaelides",
    category: "Mystery",
    rating: 4.4,
    status: "Available",
  },
  {
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    category: "Fiction",
    rating: 4.7,
    status: "Available",
  },
];

// Binary Search
function binarySearch(arr, query) {
  let left = 0;
  let right = arr.length - 1;
  const search = query.toLowerCase();

  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    const title = arr[mid].title.toLowerCase();

    if (title === search) {
      return mid;
    }

    if (title < search) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }

  return -1;
}

function Search() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [availability, setAvailability] = useState("All");

  const categories = [
    "All",
    ...new Set(books.map((book) => book.category)),
  ];

  const filteredBooks = books
    .filter((book) => {
      const matchesSearch =
        query.trim() === "" ||
        book.title.toLowerCase().includes(query.toLowerCase()) ||
        book.author.toLowerCase().includes(query.toLowerCase()) ||
        book.category.toLowerCase().includes(query.toLowerCase());

      const matchesCategory =
        category === "All" || book.category === category;

      const matchesAvailability =
        availability === "All" || book.status === availability;

      return matchesSearch && matchesCategory && matchesAvailability;
    })
    .sort((a, b) => a.title.localeCompare(b.title));

  const handleBinarySearch = () => {
    if (!query.trim()) return;

    const sortedBooks = [...books].sort((a, b) =>
      a.title.localeCompare(b.title)
    );

    const index = binarySearch(sortedBooks, query);

    if (index !== -1) {
      alert(`Book found: ${sortedBooks[index].title}`);
    } else {
      alert("Book not found");
    }
  };

  return (
    <div className="page">

      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">
          <span className="logo-icon">A</span>
          <span>Athenaeum</span>
        </div>

        <div className="nav-links">
          <a href="/">Home</a>
          <a href="/search" className="active">
            Search
          </a>
          <a href="/recommendations">
            Recommendations
          </a>
        </div>
      </nav>

      {/* Main */}
      <main className="container">

        <div className="heading">
          <p className="small-title">LIBRARY SEARCH</p>

          <h1>Find a book</h1>

          <p className="description">
            Binary search powers fast title lookup across the
            sorted collection.
          </p>
        </div>

        {/* Search */}
        <div className="search-area">

          <div className="search-box">
            <span>⌕</span>

            <input
              type="text"
              placeholder="Search by title, author, or category"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />

            {query && (
              <button
                className="clear"
                onClick={() => setQuery("")}
              >
                ×
              </button>
            )}
          </div>

          <button
            className="search-button"
            onClick={handleBinarySearch}
          >
            Search
          </button>

        </div>

        {/* Filters */}
        <div className="filters">

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="All">All Categories</option>

            {categories
              .filter((item) => item !== "All")
              .map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
          </select>

          <select
            value={availability}
            onChange={(e) =>
              setAvailability(e.target.value)
            }
          >
            <option value="All">All Availability</option>
            <option value="Available">Available</option>
            <option value="Borrowed">Borrowed</option>
          </select>

        </div>

        {/* Count */}
        <div className="result-count">
          {filteredBooks.length} books found
        </div>

        {/* Books */}
        <div className="book-list">

          {filteredBooks.length > 0 ? (
            filteredBooks.map((book) => (
              <div className="book-card" key={book.title}>

                <div className="book-category">
                  {book.category}
                </div>

                <div className="book-info">

                  <h2>{book.title}</h2>

                  <p className="author">
                    {book.author}
                  </p>

                  <div className="book-bottom">

                    <span className="rating">
                      ★ {book.rating}
                    </span>

                    <span
                      className={
                        book.status === "Available"
                          ? "available"
                          : "borrowed"
                      }
                    >
                      {book.status}
                    </span>

                  </div>

                </div>

              </div>
            ))
          ) : (
            <div className="no-results">
              <h2>No books found</h2>
              <p>
                Try searching with another title,
                author, or category.
              </p>
            </div>
          )}

        </div>

      </main>

      {/* Footer */}
      <footer>
        <div className="footer-logo">
          Athenaeum
        </div>

        <p>
          A smart library powered by binary search,
          merge sort, and graph traversal.
        </p>
      </footer>

    </div>
  );
}

export default Search;